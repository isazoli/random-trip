package validator

class Validator {

}
